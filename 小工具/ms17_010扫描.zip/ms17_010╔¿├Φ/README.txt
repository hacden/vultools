cmd命令行：
1、cping.exe scan smbvul 219.137.26.162 219.137.26.200
需要把smbcheck.exe放到如下：C:\Users\Administrator\smbcheck.exe

2、cping.exe scan smbvul
把smbcheck.exe放到如下：C:\Users\Administrator\smbcheck.exe
并需要创建如下： C:\Users\Administrator\ip.txt

